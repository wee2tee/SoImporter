dotnetdbf
=========

This is a basic file parser written in C# for reading and writing xBase DBF files, particularly Clipper.

For .net 4.0 projects there is an enumeration framework in which makes it easy to use Linq to Objects. 

Code derived from javadbf.


##Get The Source
Located in the Mecurial Repository

##Get The Binaries
Use [NuGet](http://nuget.org/packages/dotnetdbf/) from Visual Studio
