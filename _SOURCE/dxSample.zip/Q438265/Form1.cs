﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Repository;

namespace Q438265 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            gridControl1.DataSource = CreateTable(20);
            GridColumn col = gridView1.Columns.AddVisible("TradeButton", string.Empty);
            col.UnboundType = DevExpress.Data.UnboundColumnType.Object;
            RepositoryItemButtonEdit repButton = new RepositoryItemButtonEdit();
            repButton.Name = "rb1";
            repButton.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            gridControl1.RepositoryItems.Add(repButton);
            col.ColumnEdit = repButton;
            col.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            gridView1.CustomUnboundColumnData += new DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(mainView_CustomUnboundColumnData);
        }

        private DataTable CreateTable(int rowCount) {
            DataTable table = new DataTable();
            table.Columns.Add("String", typeof(string));
            table.Columns.Add("Int", typeof(int));
            table.Columns.Add("Date", typeof(DateTime));
            for (var i = 0; i < rowCount; i++) {
                table.Rows.Add(string.Format("Row {0}", i), i, DateTime.Today.AddDays(i));
            }
            return table;
        }

        private void mainView_CustomUnboundColumnData(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDataEventArgs e) {
            if (e.Column.FieldName == "TradeButton") {
                e.Value = "Trade";
            }
        }
    }
}
