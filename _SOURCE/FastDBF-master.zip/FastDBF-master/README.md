FastDBF
=======

A free and open source .net library for reading/writing DBF files. Fast and easy to use. Supports writing to forward-only streams which makes it easy to write dbf files in a web server environment.

enjoy,

Ahmed Lacevic
